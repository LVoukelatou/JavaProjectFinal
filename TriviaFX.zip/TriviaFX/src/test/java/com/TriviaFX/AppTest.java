package com.TriviaFX;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import javafx.application.Platform;
import javafx.stage.Stage;

public class AppTest {

	   private App app;

	    @BeforeClass
	    public static void initJFX() {
	        // Εκκίνηση του JavaFX toolkit πριν από τα tests
	        Platform.startup(() -> {});
	    }

	    @Before
	    public void setUp() {
	        app = new App();
	    }

	    @Test
	    public void testAppCreation() {
	        assertNotNull("Το αντικείμενο App δεν πρέπει να είναι null", app);
	    }

	    @Test
	    public void testScenesNotNull() {
	        Platform.runLater(() -> {
	            app.start(new Stage()); // Εκκίνηση της εφαρμογής σε νέο Stage
	            assertNotNull("Η startScene δεν πρέπει να είναι null", App.startScene);
	            assertNotNull("Η parameterScene δεν πρέπει να είναι null", App.parameterScene);
	        });
	    }

}
