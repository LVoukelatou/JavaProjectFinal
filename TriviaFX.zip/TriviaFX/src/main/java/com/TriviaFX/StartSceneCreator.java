package com.TriviaFX;

import java.util.List;

import com.triviaapi.TriviaAPIClient;
import com.triviaapi.models.Question;

import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.FlowPane;

public class StartSceneCreator implements EventHandler<MouseEvent> {
	int width,height;
			//Flow pane root node
			public FlowPane rootFlowPane;
			// 	ParameteScene buttons
			Button choiceBtn, defaultBtn;
	
	public StartSceneCreator (int width, int height) {
		
		this.width= width;
		this.height = height;
		rootFlowPane = new FlowPane();
			
    	choiceBtn = new Button ("Customize the game");
    	defaultBtn = new Button ("Default Choices");
		
    	//attach handle event to choice button
    	choiceBtn.setOnMouseClicked(this);
    	
    	//attach handle event to default button
    	defaultBtn.setOnMouseClicked(this);
    	
    	//setup flow pane
    	rootFlowPane.setHgap(10);
    	rootFlowPane.setAlignment(Pos.CENTER);
    	choiceBtn.setMinSize(120, 30);
    	defaultBtn.setMinSize(120, 30);
		
    	
    	//add buttons to flow pane
    	rootFlowPane.getChildren().add(choiceBtn);
    	rootFlowPane.getChildren().add(defaultBtn);
	}


	public Scene createScene() {
		return new Scene(rootFlowPane, width, height);
	}


	@Override
	public void handle(MouseEvent event) {
		// TODO Auto-generated method stub
		if (event.getSource() == choiceBtn) {
			App.primaryStage.setScene(App.parameterScene);}
			else {
				TriviaAPIClient client = new TriviaAPIClient();
				List<Question> questions = client.fetchQuestions(5, null, null, null);
				App.gameScene = new GameSceneCreator(questions, 5, null, null, null).createScene();  // Δημιουργία σκηνής παιχνιδιού
				App.primaryStage.setScene(App.gameScene);
			}
				
	}
}

