package com.TriviaFX;

import java.util.List;

import com.triviaapi.models.Question;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 * JavaFX App
 */
public class App extends Application  {
	//Stage
	public static Stage primaryStage;
	//Scene 
	static Scene startScene;
	public static Scene parameterScene;
	public static Scene gameScene;
	String selectedType,selectedCategory,selectedDifficulty;
	int selectedAmount;
	List <Question> questions;
	
    @Override
    public void start(Stage primaryStage) {
    	App.primaryStage = primaryStage;
    	
    	StartSceneCreator StartSceneCreator = new StartSceneCreator(650,300);
    	startScene = StartSceneCreator.createScene();
    	
    	ParameterSceneCreator ParameterSceneCreator = new ParameterSceneCreator();
    	parameterScene = ParameterSceneCreator.createScene();
    	
    	
    	primaryStage.setTitle("Trivia Game");
    	primaryStage.setScene(startScene);
    	primaryStage.show();
    	
    }

    public static void main(String[] args) {
        launch();
    }

	

	

	
		
	}

