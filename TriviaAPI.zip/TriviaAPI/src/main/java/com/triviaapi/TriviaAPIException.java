package com.triviaapi;

public class TriviaAPIException extends RuntimeException {
    public TriviaAPIException(String message) {
        super(message);
    }

    public TriviaAPIException(String message, Throwable cause) {
        super(message, cause);
    }
}
