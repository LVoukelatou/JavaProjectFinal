module triviaAPI {
	exports com.triviaapi;
	exports com.triviaapi.models;

	requires com.fasterxml.jackson.annotation;
	requires com.fasterxml.jackson.core;
	requires com.fasterxml.jackson.databind;
	requires okhttp3;
	requires org.apache.commons.text;
	requires org.slf4j;
	
	opens com.triviaapi to com.fasterxml.jackson.databind;
}