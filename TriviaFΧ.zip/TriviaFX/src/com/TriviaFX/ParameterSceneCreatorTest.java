package com.TriviaFX;

import static org.junit.Assert.*;

import java.util.concurrent.CountDownLatch;

import org.junit.BeforeClass;
import org.junit.Test;

import javafx.application.Platform;
import javafx.scene.Scene;

public class ParameterSceneCreatorTest {

	private static ParameterSceneCreator parameterSceneCreator;

    @BeforeClass
    public static void initJavaFX() throws InterruptedException {
        // Εκκίνηση του JavaFX Toolkit
        CountDownLatch latch = new CountDownLatch(1);
        Platform.startup(latch::countDown); // Καλεί την εκκίνηση του JavaFX
        latch.await(); // καθυστερώ λίγο μέχρι να ολοκληρωθεί η εκκίνηση
    }

    @Test
    public void testCreateSceneNotNull() {
        // Δημιουργούμε την ParameterSceneCreator αφού το JavaFX έχει εκκινηθεί
        parameterSceneCreator = new ParameterSceneCreator();
        
        // Δημιουργούμε τη σκηνή
        Scene scene = parameterSceneCreator.createScene();
        
        // Ελέγχουμε αν η σκηνή δεν είναι null
        assertNotNull("Η σκηνή δεν πρέπει να είναι null", scene);
    }
}


