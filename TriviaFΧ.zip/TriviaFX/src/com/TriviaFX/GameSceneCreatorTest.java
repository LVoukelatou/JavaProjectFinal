package com.TriviaFX;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;


import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.triviaapi.models.Question;

import javafx.application.Platform;



public class GameSceneCreatorTest {

    private GameSceneCreator gameScene;
    private List<Question> testQuestions;
    
    // Εκκίνηση JavaFX πριν τρέξουν τα tests
    @BeforeClass
    public static void initJFX() {
        Platform.startup(() -> {});
    }

    @Before
    public void setUp() {
        // Δημιουργία ερωτήσεων (χωρίς UI)
        Question q1 = new Question();
        q1.setQuestion("What is 2+2?");
        q1.setCorrectAnswer("4");
        q1.setIncorrectAnswers(new String[]{"3", "5", "6"});
        q1.setType("multiple");

        testQuestions = new ArrayList<>();
        testQuestions.add(q1);

        // Δημιουργία αντικειμένου GameSceneCreator
        gameScene = new GameSceneCreator(testQuestions, 1, "Math", "easy", "multiple");
    }

    @Test
    public void testGameSceneCreatorInitialization() {
        assertNotNull("Το αντικείμενο GameSceneCreator δεν πρέπει να είναι null", gameScene);
        assertEquals("Ο αριθμός ερωτήσεων πρέπει να είναι 1", 1, gameScene.questions.size());
    }
}