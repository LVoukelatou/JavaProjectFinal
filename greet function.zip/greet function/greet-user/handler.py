def handle(req):
    """
    Δέχεται όνομα χρήστη (JSON με key "name") και επιστρέφει έναν χαιρετισμό
    μαζί με την τρέχουσα ημερομηνία και ώρα του server.
    """
    import json
    from datetime import datetime

    try:
        data = json.loads(req)
        name = data.get("name", "φίλε/φίλη")
        now = datetime.now().strftime("%d/%m/%Y %H:%M:%S")
        
        response = {
            "greeting": f"Γεια σου, {name}! Καλώς ήρθες στην serverless υπηρεσία μας!",
            "timestamp": f"Ημερομηνία και ώρα αιτήματος: {now}"
        }

        return json.dumps(response, ensure_ascii=False)

    except Exception as e:
        return json.dumps({"error": f"Σφάλμα επεξεργασίας: {str(e)}"}, ensure_ascii=False)