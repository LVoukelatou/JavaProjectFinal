package com.TriviaFX;

import static org.junit.Assert.*;

import java.util.concurrent.CountDownLatch;

import org.junit.BeforeClass;
import org.junit.Test;

import javafx.application.Platform;
import javafx.scene.Scene;

public class StartSceneCreatorTest {

    private StartSceneCreator startSceneCreator;

    @BeforeClass
    public static void initJavaFX() throws InterruptedException {
        // Εκκίνηση του JavaFX Toolkit
        CountDownLatch latch = new CountDownLatch(1);
        Platform.startup(latch::countDown); // Το Platform.startup εκκινεί το JavaFX
        latch.await(); // Περιμένουμε μέχρι να ολοκληρωθεί η εκκίνηση
    }

    @Test
    public void testCreateSceneNotNull() {
        // Δημιουργούμε το αντικείμενο StartSceneCreator μετά την εκκίνηση του JavaFX Toolkit
        startSceneCreator = new StartSceneCreator(800, 600);
        
        // Δημιουργούμε τη σκηνή
        Scene scene = startSceneCreator.createScene();
        
        // Ελέγχουμε αν η σκηνή δεν είναι null
        assertNotNull("Η σκηνή δεν πρέπει να είναι null", scene);
    }
	}


