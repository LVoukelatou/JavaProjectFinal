module com.TriviaFX {
    requires javafx.controls;
	requires javafx.graphics;
	requires javafx.base;
	requires java.desktop;
	requires triviaAPI;
    exports com.TriviaFX;
	requires java.base;
	requires jdk.javadoc;
	
	requires static junit;
	opens com.TriviaFX to junit;
}