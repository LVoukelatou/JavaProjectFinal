package com.TriviaFX;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.triviaapi.TriviaAPIClient;
import com.triviaapi.TriviaAPIException;
import com.triviaapi.models.Question;

import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.MenuButton;
import javafx.scene.control.MenuItem;
import javafx.scene.control.Spinner;
import javafx.scene.control.SpinnerValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.VBox;

public class ParameterSceneCreator implements EventHandler<MouseEvent> {
		// VBox pane root node
		VBox rootVBoxPane;
		// one label for every parameter we need
		Label amountLbl, categoryLbl, difficultyLbl, typeLbl, errorLbl;
		//the player can choose the number of questions they need
		Spinner<Integer>  amountSpinner;
		// the player have to choose category, difficulty and type from a menu
		MenuButton categoryBtn, difficultyBtn, typeBtn;
		MenuItem anyType,multipleChoice,trueOrFalse, anyDifficulty, easy, medium, hard, anyCategory,generalKnowledge,books,film,music,theaters,tv,vGames,bGames,nature,computers,math,mythology,sports,geography,history,politics,art,celebrities,animals,vehicles,comics,anime,cartoon,gadgets;
		FlowPane actionFlowPane;
		//back button and submit button
		Button backBtn, nextBtn;
		String selectedType, selectedDifficulty, selectedCategory, type, difficulty;
		int selectedAmount, selectedCategoryID, amount, category;
		List<Question> questions;
		private static final Map<String, Integer> categoryMap = new HashMap<>(); //HashMap with default initial capacity (16) and default load factor (0.75)
		
		public int getSelectedAmount() {
		    return selectedAmount;
		}

		public String getSelectedType() {
		    return selectedType;
		}

		public String getSelectedDifficulty() {
		    return selectedDifficulty;
		}

		public int getSelectedCategoryID() {
		    return selectedCategoryID;
		}

		public Spinner<Integer> getAmountSpinner() {
		    return amountSpinner;
		}

		public Button getBackButton() {
		    return backBtn;
		}

		public ParameterSceneCreator () {
		rootVBoxPane = new VBox();
		amountLbl = new Label("Select Number of Questions (<=50)");
		categoryLbl = new Label ("Select Category");
		difficultyLbl = new Label ("Select Difficulty");
		typeLbl = new Label ("Select Type");
		amountSpinner = new Spinner<>();
    	categoryBtn = new MenuButton ("None");
    	difficultyBtn = new MenuButton ("None");
    	typeBtn = new MenuButton ("None");
    	backBtn = new Button ("Go Back");
    	nextBtn = new Button ("Play");
    	actionFlowPane = new FlowPane(backBtn, nextBtn);
    	errorLbl = new Label();
    	
    	
    	//default parameters
    	type = "Any Type";
    	difficulty = "Any Difficulty";
    	amount = 5;
    	category = 0; // Default "Any Category"
    	
    	//setup VBox pane
    	rootVBoxPane.setMinSize(650, 300);
    	rootVBoxPane.setSpacing(10);
    	rootVBoxPane.setAlignment(Pos.CENTER);
    
    	//setup flow pane
    	actionFlowPane.setHgap(10);
    	actionFlowPane.setAlignment(Pos.CENTER);
    	nextBtn.setMinSize(120, 30);
    	backBtn.setOnAction(event -> App.primaryStage.setScene(App.startScene));
    	backBtn.setMinSize(120, 30);
    	
    	
    	//set the amount spinner 
    	SpinnerValueFactory<Integer>valueFactory = new SpinnerValueFactory.IntegerSpinnerValueFactory(3,50,3); //at least 3 questions but no more than 50
    	amountSpinner.setValueFactory(valueFactory);
    	amountSpinner.valueProperty().addListener((obs, oldVal, newVal) -> {
    	    selectedAmount = newVal;
    	});
    	selectedAmount = amountSpinner.getValue();
   
    	
    	
    		
    	//set the Drop down menu
    	MenuItem anyCategory = new MenuItem ("Any Category");
    	MenuItem generalKnowledge = new MenuItem ("General Knowledge");
    	MenuItem books = new MenuItem ("Entertainment: Books");
    	MenuItem film = new MenuItem ("Entertainment: Film");
    	MenuItem music = new MenuItem ("Entertainment: Music");
    	MenuItem theaters = new MenuItem ("Entertainment: Musicals & Theaters");
    	MenuItem tv = new MenuItem ("Entertainment: Television");
    	MenuItem vGames = new MenuItem ("Entertainment: Video Games");
    	MenuItem bGames = new MenuItem ("Entertainment: Board Games");
    	MenuItem nature = new MenuItem ("Science & Nature");
    	MenuItem computers = new MenuItem ("Science: Computers");
    	MenuItem math =  new MenuItem ("Science: Mathematics");
    	MenuItem mythology = new MenuItem ("Mythology");
    	MenuItem sports = new MenuItem ("Sports");
    	MenuItem geography = new MenuItem ("Geography");
    	MenuItem history = new MenuItem ("History");
    	MenuItem politics = new MenuItem ("Politics");
    	MenuItem art = new MenuItem ("Art");
    	MenuItem celebrities = new MenuItem ("Celebrities");
    	MenuItem animals = new MenuItem ("Animals");
    	MenuItem vehicles = new MenuItem ("Vehicles");
    	MenuItem comics = new MenuItem ("Entertainment: Comics");
    	MenuItem anime = new MenuItem ("Entertainment: Japanese Anime & Manga");
    	MenuItem cartoon = new MenuItem ("Entertainment: Cartoon & Animations");
    	MenuItem gadgets = new MenuItem ("Science: Gadgets");
    	
    	categoryMap.put("Any Category", 0);
		categoryMap.put("General Knowledge", 9);
		categoryMap.put("Entertainment: Books", 10);
		categoryMap.put("Entertainment: Film", 11);
		categoryMap.put("Entertainment: Music", 12);
		categoryMap.put("Entertainment: Musicals & Theaters", 13);
		categoryMap.put("Entertainment: Television", 14);
		categoryMap.put("Entertainment: Video Games", 15);
		categoryMap.put("Entertainment: Board Games", 16);
		categoryMap.put("Science & Nature", 17);
		categoryMap.put("Science: Computers", 18);
		categoryMap.put("Science: Mathematics", 19);
		categoryMap.put("Mythology", 20);
		categoryMap.put("Sports", 21);
		categoryMap.put("Geography", 22);
		categoryMap.put("History", 23);
		categoryMap.put("Politics", 24);
		categoryMap.put("Art", 25);
		categoryMap.put("Celebrities", 26);
		categoryMap.put("Animals", 27);
		categoryMap.put("Vehicles", 28);
		categoryMap.put("Entertainment: Comics", 29);
		categoryMap.put("Entertainment: Japanese Anime & Manga", 31);
		categoryMap.put("Entertainment: Cartoon & Animations", 32);
		categoryMap.put("Science: Gadgets", 30);
		
		
    	categoryBtn.getItems().addAll(anyCategory,generalKnowledge,books,film,music,theaters,tv,vGames,bGames,nature,computers,math,mythology,sports,geography,history,politics,art,celebrities,animals,vehicles,comics,anime,cartoon,gadgets);
    	
    	
    	
    	MenuItem anyDifficulty = new MenuItem ("Any Difficulty");
		MenuItem easy = new MenuItem ("Easy");
		MenuItem medium = new MenuItem ("Medium");
		MenuItem hard = new MenuItem ("Hard");
		//add menu items to the menu typeBtn
    	difficultyBtn.getItems().addAll(anyDifficulty, easy, medium, hard);
    

    	
    	MenuItem anyType = new MenuItem ("Any Type");
		MenuItem multipleChoice = new MenuItem ("Multiple Choice");
		MenuItem trueOrFalse = new MenuItem ("True or False");
		//add menu items to the menu typeBtn
    	typeBtn.getItems().addAll(anyType, multipleChoice, trueOrFalse);
    	
    	
    	//add buttons, labels and fields to the VBox
    	rootVBoxPane.getChildren().addAll(
    			amountLbl,amountSpinner,
    			categoryLbl, categoryBtn,
    			difficultyLbl, difficultyBtn,
    			typeLbl, typeBtn
    			);
    	rootVBoxPane.getChildren().add(actionFlowPane);
    	
    	rootVBoxPane.getChildren().add(errorLbl);
    	
    	
    	
    	//attach handle event to back button
    	amountSpinner.setOnMouseClicked(this);
    	
    
    	 anyType.setOnAction(event -> {
             selectedType = "Any Type";
             typeBtn.setText(selectedType);
         });
    	 multipleChoice.setOnAction(event -> {
             selectedType = "Multiple Choice";
             typeBtn.setText(selectedType);
         });
    	 trueOrFalse.setOnAction(event -> {
             selectedType = "True or False";
             typeBtn.setText(selectedType);
         });
		
    	 anyDifficulty.setOnAction(event -> {
             selectedDifficulty = "Any Difficulty";
             difficultyBtn.setText(selectedDifficulty);
         });
    	 easy.setOnAction(event -> {
             selectedDifficulty = "Easy";
             difficultyBtn.setText(selectedDifficulty);
         });
    	 medium.setOnAction(event -> {
             selectedDifficulty = "Medium";
             difficultyBtn.setText(selectedDifficulty);
         });
    	 hard.setOnAction(event -> {
             selectedDifficulty = "Hard";
             difficultyBtn.setText(selectedDifficulty);
         });
    	 anyCategory.setOnAction(event -> {
    		 selectedCategoryID = categoryMap.get("Any Category");
    		 categoryBtn.setText("Any Category");
         }); 

    	 generalKnowledge.setOnAction(event -> {
    		 selectedCategoryID = categoryMap.get("General Knowledge");
             categoryBtn.setText("General Knowledge");
         }); 
    	 books.setOnAction(event -> {
             selectedCategoryID = categoryMap.get("Entertainment: Books");
             categoryBtn.setText("Entertainment: Books");
         }); 
    	 film.setOnAction(event -> {
             selectedCategoryID = categoryMap.get("Entertainment: Film");
             categoryBtn.setText("Entertainment: Film");
         }); 
    	 music.setOnAction(event -> {
             selectedCategoryID = categoryMap.get("Entertainment: Music");
             categoryBtn.setText("Entertainment: Music");
         }); 
    	 theaters.setOnAction(event -> {
             selectedCategoryID = categoryMap.get("Entertainment: Musicals & Theaters");
             categoryBtn.setText("Entertainment: Musicals & Theaters");
         }); 
    	 tv.setOnAction(event -> {
             selectedCategoryID = categoryMap.get("Entertainment: Television");
             categoryBtn.setText("Entertainment: Television");
         }); 
    	 vGames.setOnAction(event -> {
             selectedCategoryID = categoryMap.get("Entertainment: Video Games");
             categoryBtn.setText("Entertainment: Video Games");
         }); 
    	 bGames.setOnAction(event -> {
             selectedCategoryID = categoryMap.get("Entertainment: Board Games");
             categoryBtn.setText("Entertainment: Board Games");
         }); 
    	 nature.setOnAction(event -> {
             selectedCategoryID = categoryMap.get("Science & Nature");
             categoryBtn.setText("Science & Nature");
         }); 
    	 
    	 computers.setOnAction(event -> {
             selectedCategoryID = categoryMap.get("Science: Computers");
             categoryBtn.setText("Science: Computers");
         }); 
    	 
    	 math.setOnAction(event -> {
             selectedCategoryID = categoryMap.get("Science: Mathematics");
             categoryBtn.setText("Science: Mathematics");
         }); 
    	 mythology.setOnAction(event -> {
             selectedCategoryID = categoryMap.get("Mythology");
             categoryBtn.setText("Mythology");
         }); 
    	 sports.setOnAction(event -> {
             selectedCategoryID = categoryMap.get("Sports");
             categoryBtn.setText("Sports");
         }); 
    	 geography.setOnAction(event -> {
             selectedCategoryID = categoryMap.get("Geography");
             categoryBtn.setText("Geography");
         }); 
    	 history.setOnAction(event -> {
             selectedCategoryID = categoryMap.get("History");
             categoryBtn.setText("History");
         }); 
    	 politics.setOnAction(event -> {
             selectedCategoryID = categoryMap.get("Politics");
             categoryBtn.setText("Politics");
         }); 
    	
    	 art.setOnAction(event -> {
             selectedCategoryID = categoryMap.get("Art");
             categoryBtn.setText("Art");
         }); 
    	 celebrities.setOnAction(event -> {
             selectedCategoryID = categoryMap.get("Celebrities");
             categoryBtn.setText("Celebrities");
         }); 
    	 animals.setOnAction(event -> {
             selectedCategoryID = categoryMap.get("Animals");
             categoryBtn.setText("Animals");
         }); 
    	 vehicles.setOnAction(event -> {
             selectedCategoryID = categoryMap.get("Vehicles");
             categoryBtn.setText("Vehicles");
         }); 
    	 comics.setOnAction(event -> {
             selectedCategoryID = categoryMap.get("Entertainment: Comics");
             categoryBtn.setText("Entertainment: Comics");
         }); 
    	 anime.setOnAction(event -> {
             selectedCategoryID = categoryMap.get("Entertainment: Japanese Anime & Manga");
             categoryBtn.setText("Entertainment: Japanese Anime & Manga");
         }); 
    	 cartoon.setOnAction(event -> {
             selectedCategoryID = categoryMap.get("Entertainment: Cartoon & Animations");
             categoryBtn.setText("Entertainment: Cartoon & Animations");
         }); 
    	 gadgets.setOnAction(event -> {
             selectedCategoryID = categoryMap.get("Science: Gadgets");
             categoryBtn.setText("Science: Gadgets");
         }); 
    	 
    
     	nextBtn.setOnAction(event -> {
 		    TriviaAPIClient client = new TriviaAPIClient();
 		    
 		    int amount = amountSpinner.getValue();
 		    String category = selectedCategoryID == 0 ? null : String.valueOf(selectedCategoryID);
 		   if ("Any Difficulty".equals(selectedDifficulty)) {
 			    selectedDifficulty = null;
 			} else if (selectedDifficulty != null) {
 			    selectedDifficulty = selectedDifficulty.toLowerCase();
 			}
 		   String difficulty = selectedDifficulty;
 		   
 		  if ("Any Type".equals(selectedType)) {
 			    selectedType = null;
 			} else if (selectedType != null) {
 			    selectedType = selectedType.equals("Multiple Choice") ? "multiple" : "boolean";
 			}
 		  String type = selectedType;
 		    
 		    try {
 		        List<Question> questions = client.fetchQuestions(amount, category, difficulty, type);
 		       if (questions == null || questions.isEmpty()) {
 	                throw new TriviaAPIException("No questions received from the API.");}
 		        App.gameScene = new GameSceneCreator(questions, amount, category, difficulty, type).createScene();  // Δημιουργία σκηνής παιχνιδιού
 		        App.primaryStage.setScene(App.gameScene);
 		    } catch (TriviaAPIException e) {
 		        e.printStackTrace();
 		       errorLbl.setText("Not enough questions for the existing parameters... Please Try Again :)");
 		       errorLbl.setVisible(true);
 		      questions = new ArrayList<>(); // Αποφεύγουμε το NullPointerException
 		    }
 		});
}
		
		
		public Scene createScene () {
			return new Scene(rootVBoxPane);
		}


		@Override
		public void handle(MouseEvent event) {
			// TODO Auto-generated method stub
			
		}
			
}
