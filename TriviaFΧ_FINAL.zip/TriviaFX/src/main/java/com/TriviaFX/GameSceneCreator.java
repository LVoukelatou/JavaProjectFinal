package com.TriviaFX;



import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.triviaapi.TriviaAPIClient;
import com.triviaapi.TriviaAPIException;
import com.triviaapi.models.Question;

import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.layout.VBox;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;



public class GameSceneCreator  {
	
	private int currentQuestionIndex;
	List <Question> questions;
	private VBox gameRootPane;
	Label questionLbl;
	Label scoreLbl;
	Label highScoreLbl;
	Label answerLbl;
	Button[] answerBtn;
	private int score;
	private Button playAgainBtn, newGameBtn;
    private String selectedCategory, selectedDifficulty, selectedType;
    private int selectedAmount;
    private static int highScore = -1; // Αρχικοποίηση σε -1, θα είναι -1 αν δεν έχουμε highScore για τις τρέχουσες παραμέτρους



	public GameSceneCreator (List<Question> questions, int amount, String category, String difficulty, String type) {
		this.questions = questions;
	    this.selectedAmount = amount;
	    this.selectedCategory = category;
	    this.selectedDifficulty = difficulty;
	    this.selectedType = type;
		this.questions = questions;
		gameRootPane = new VBox();
		currentQuestionIndex = 0;
		answerBtn = new Button[4]; 
		score=0;
		
		 // Αν το highScore δεν έχει οριστεί, το ορίζουμε σε 0 για το τρέχον παιχνίδι
        if (highScore == -1) {
            highScore = 0;
        }
        
		scoreLbl=new Label("Score: " + score);
		highScoreLbl=new Label ("High Score: "+ highScore);
		gameRootPane.getChildren().add(scoreLbl);
		gameRootPane.getChildren().add(highScoreLbl);
		
		
	    gameRootPane.setMinSize(650, 300);
    	gameRootPane.setSpacing(10);
    	gameRootPane.setAlignment(Pos.CENTER);
    	
    	questionLbl = new Label();
    	answerLbl = new Label ();
    	gameRootPane.getChildren().add(answerLbl);
		gameRootPane.getChildren().add(questionLbl);
		
		
		 for (int i = 0; i < 4; i++) {
	            answerBtn[i] = new Button();
	            answerBtn[i].setMinWidth(300);
	            gameRootPane.getChildren().add(answerBtn[i]);
	        }
		 
		 
		 	playAgainBtn = new Button("Play Again with the same parameters");
	        playAgainBtn.setOnAction(event -> resetGame());  // Ανάθεση δράσης στο κουμπί
	        playAgainBtn.setVisible(false);  // Αρχικά δεν είναι ορατό το κουμπί
	        gameRootPane.getChildren().add(playAgainBtn);
	        
	        
	        newGameBtn = new Button ("Play a new game");
	        newGameBtn.setVisible(false);
	        
	        gameRootPane.getChildren().add(newGameBtn);
	        
	        highScoreLbl.setVisible(false);
	       
	        showQuestion();
	    }
	
	
	  void showQuestion() {
	        if (currentQuestionIndex >= questions.size()) {
	            questionLbl.setText("Game Over!");
	            if (score > highScore) {
	                highScore = score;
	                highScoreLbl.setText("NEW HIGH SCORE! " + highScore);
	            }
	            else {
	                highScoreLbl.setText("High Score: " + highScore);
	            }
	            playAgainBtn.setVisible(true);  // Εμφάνιση κουμπιού για επανεκκίνηση
	            newGameBtn.setVisible(true); //Εμφάνιση κουμπιού για επιλογή νέων παραμέτρων
	            newGameBtn.setOnAction(event -> {
	            	highScore = 0; // Μηδενισμός του highScore όταν πατάει "New Game"
	            	App.primaryStage.setScene(App.startScene);
	            });
	            highScoreLbl.setVisible(true);
	            for (Button button : answerBtn) {
	                button.setVisible(false); // Απόκρυψη των κουμπιών απαντήσεων
	            }
	            return;
	            }
	        
	        Question currentQuestion = questions.get(currentQuestionIndex);
	        questionLbl.setText(currentQuestion.getQuestion());

	        // λίστα με όλες τις απαντήσεις
	        List<String> allAnswers = new ArrayList<>();
	    
	        if (currentQuestion.getType().equals("boolean")) { //ελέγχω αν ειναι True/False
	            allAnswers.add("True");
	            allAnswers.add("False");
	        } else { //  Multiple Choice
	            allAnswers.add(currentQuestion.getCorrectAnswer());
	            Collections.addAll(allAnswers, currentQuestion.getIncorrectAnswers());
	        }
	        
	        Collections.shuffle(allAnswers); // Ανακάτεμα απαντήσεων

	        // Ανάθεση απαντήσεων στα κουμπιά
	        for (int i = 0; i < answerBtn.length; i++) {
	                if (i < allAnswers.size()) {
	                    // Εμφάνιση των κουμπιών που περιέχουν απαντήσεις
	                    answerBtn[i].setText(allAnswers.get(i));
	                    answerBtn[i].setVisible(true);
	                    String selectedAnswer = allAnswers.get(i);
	                    

	                    // Ανάθεση δράσης στο κουμπί
	                    answerBtn[i].setOnAction(event -> {
	                        if (selectedAnswer.equals(currentQuestion.getCorrectAnswer())) {
	                        	 answerLbl.setText("Correct!");
	                            score+=10;
	                            scoreLbl.setText("Score: " + score);
	                          
	                        } else {
	                            answerLbl.setText("Wrong!");
	                            scoreLbl.setText("Score: " + score);
	                        }
	                        currentQuestionIndex++;
	                        showQuestion();  // Φόρτωση επόμενης ερώτησης
	                    });
	                } else {
	                    // Αν έχουμε λιγότερες απαντήσεις, τα υπόλοιπα κουμπιά γίνονται αόρατα
	                    answerBtn[i].setVisible(false);
	                }}

	        }


			void resetGame() {
	        	TriviaAPIClient client = new TriviaAPIClient();
	            try {
	                List<Question> newQuestions = client.fetchQuestions(selectedAmount,selectedCategory, selectedDifficulty, selectedType);

	                if (newQuestions == null || newQuestions.isEmpty()) {
	                    throw new TriviaAPIException("No questions received from the API.");
	                }
	                App.gameScene = new GameSceneCreator(newQuestions, selectedAmount, selectedCategory, selectedDifficulty, selectedType).createScene();
	                App.primaryStage.setScene(App.gameScene);
	            } catch (TriviaAPIException e) {
	                e.printStackTrace();
	                questionLbl.setText("Not enough questions for the existing parameters...Please Try Again :) ");
	            }
	        		
	            
	                score = 0;  // Επαναφορά σκορ
	                highScoreLbl.setVisible(false);
	                scoreLbl.setText("Score: " + score);
	                currentQuestionIndex = 0;  // Επαναφορά της ερώτησης στην πρώτη
	                for (Button button : answerBtn) {
	                    button.setVisible(true);  // Επαναφορά των κουμπιών
	                }
	                playAgainBtn.setVisible(false);  // Απόκρυψη του κουμπιού Play Again
	                questionLbl.setText("");  // Άδειασμα του label
	            
	        
	        }
	public Scene createScene() {
		// TODO Auto-generated method stub
		return new Scene (gameRootPane);
	}
	
	
	

}
	


