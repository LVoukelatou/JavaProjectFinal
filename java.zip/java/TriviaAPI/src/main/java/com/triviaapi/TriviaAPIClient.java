package com.triviaapi;

import okhttp3.HttpUrl;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.triviaapi.models.Question;
import org.apache.commons.text.StringEscapeUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;

public class TriviaAPIClient {

    private static final String API_URL = "https://opentdb.com/api.php?amount=10";
    private final OkHttpClient httpClient;
    private final ObjectMapper objectMapper;
    private static final Logger logger = LoggerFactory.getLogger(TriviaAPIClient.class);

    public TriviaAPIClient() {
        this.httpClient = new OkHttpClient();
        this.objectMapper = new ObjectMapper();
    }

    public TriviaAPIClient(OkHttpClient httpClient, ObjectMapper objectMapper) {
        this.httpClient = httpClient;
        this.objectMapper = objectMapper;
    }

    public List<Question> fetchQuestions(int amount, String category, String difficulty, String type) throws TriviaAPIException {
        HttpUrl.Builder urlBuilder = HttpUrl.parse(API_URL).newBuilder();
        urlBuilder.addQueryParameter("amount", String.valueOf(amount));
        if (category != null) urlBuilder.addQueryParameter("category", category);
        if (difficulty != null) urlBuilder.addQueryParameter("difficulty", difficulty);
        if (type != null) urlBuilder.addQueryParameter("type", type);

        Request request = new Request.Builder()
                .url(urlBuilder.build())
                .build();

        try (Response response = httpClient.newCall(request).execute()) {
            if (!response.isSuccessful()) {
                logger.error("Failed to fetch questions: HTTP " + response.code());
                throw new TriviaAPIException("Unexpected HTTP code: " + response.code());
            }

            ApiResponse apiResponse = objectMapper.readValue(response.body().string(), ApiResponse.class);

            if (apiResponse.getResponseCode() != 0) {
                logger.error("Error fetching questions: response code " + apiResponse.getResponseCode());
                throw new TriviaAPIException("API error: response code " + apiResponse.getResponseCode());
            }

            // Αποσυμβολοποίηση των HTML entities στις ερωτήσεις
            apiResponse.getResults().forEach(this::decodeQuestionHtml);

            return apiResponse.getResults();
        } catch (IOException e) {
            logger.error("IOException occurred: " + e.getMessage(), e);
            throw new TriviaAPIException("Error fetching questions", e);
        }
    }

    // Μέθοδος για αποσυμβολοποίηση HTML entities στις ερωτήσεις
    private void decodeQuestionHtml(Question question) {
        question.setQuestion(StringEscapeUtils.unescapeHtml4(question.getQuestion()));
        question.setCorrectAnswer(StringEscapeUtils.unescapeHtml4(question.getCorrectAnswer()));
        question.setIncorrectAnswers(
            // Convert the List to a String[] array before setting it
            Arrays.stream(question.getIncorrectAnswers())
                .map(StringEscapeUtils::unescapeHtml4)
                .toArray(String[]::new)
        );
    }



    private static class ApiResponse {
        @JsonProperty("response_code")
        private int responseCode;

        @JsonProperty("results")
        private List<Question> results;

        public int getResponseCode() {
            return responseCode;
        }

        public void setResponseCode(int responseCode) {
            this.responseCode = responseCode;
        }

        public List<Question> getResults() {
            return results;
        }

        public void setResults(List<Question> results) {
            this.results = results;
        }
    }
}
